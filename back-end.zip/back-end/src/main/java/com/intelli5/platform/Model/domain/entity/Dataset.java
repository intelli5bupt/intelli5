package com.intelli5.platform.Model.domain.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import lombok.Data;

/**
 * 
 * @TableName dataset
 */
@TableName(value ="dataset")
@Data
public class Dataset implements Serializable {
    /**
     * 
     */
    @TableId(type = IdType.AUTO)
    private Integer id;

    /**
     * 
     */
    private String datasetName;

    /**
     * 
     */
    private String datasetAddress;

    /**
     * 
     */
    private Integer jobId;

    /**
     * 
     */
    private Integer deviceId;

    /**
     * 
     */
    private Integer userId;

    /**
     * 
     */
    private String deviceIP;

    /**
     * 
     */
    private String devicePort;

    /**
     * 
     */
    private String supportJob;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}