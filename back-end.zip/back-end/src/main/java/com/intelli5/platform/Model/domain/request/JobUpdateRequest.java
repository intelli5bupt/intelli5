package com.intelli5.platform.Model.domain.request;

import lombok.Data;

import java.io.Serializable;

@Data
public class JobUpdateRequest implements Serializable {

    private static final long serialVersionUID = 7874163451122593524L;

    private Integer id;

    private String jobModelName;

    private String budget;

    private String modelDeployStrategy;

    private String jobSafetyStrategy;

    private Integer userId;
}
