package com.intelli5.platform.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.intelli5.platform.Mapper.JobMapper;
import com.intelli5.platform.Mapper.ModelMapper;
import com.intelli5.platform.Model.domain.entity.Job;
import com.intelli5.platform.Model.domain.entity.Model;
import com.intelli5.platform.common.BaseResponse;
import com.intelli5.platform.common.ErrorCode;
import com.intelli5.platform.common.ResultUtils;
import com.intelli5.platform.service.JobService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
* @author lenovo
* @description 针对表【job】的数据库操作Service实现
* @createDate 2022-11-24 13:43:44
*/
@Service
public class JobServiceImpl extends ServiceImpl<JobMapper, Job>
    implements JobService{

    @Resource
    private ModelMapper modelMapper;

    @Resource
    private JobMapper jobMapper;

    @Override
    public BaseResponse validJob(Job job, boolean add) {
        if (job == null) {
//            throw new BusinessException(ErrorCode.PARAMS_ERROR);
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "有参数为空");
        }

        String jobName = job.getJobName();
        String jobDescription = job.getJobDescription();
        String jobType = job.getJobType();
        String jobTypeDescription = job.getJobTypeDescription();
        String jobModelName = job.getJobModelName();
        String budget = job.getBudget();
        String modelDeployStrategy = job.getModelDeployStrategy();
        String jobSafetyStrategy = job.getJobSafetyStrategy();
        String jobDatasetDescription = job.getJobDatasetDescription();

        //所有参数都为 非空
        if (add) {
            if (StringUtils.isAnyBlank(jobName, jobDescription, jobType,jobTypeDescription, jobModelName, budget, modelDeployStrategy, jobSafetyStrategy,jobDatasetDescription)) {
//                throw new BusinessException(ErrorCode.PARAMS_ERROR);
                return ResultUtils.error(ErrorCode.PARAMS_ERROR, "有参数为空");
            }
        }

        QueryWrapper<Model> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("modelName", jobModelName);

        long count = modelMapper.selectCount(queryWrapper);
        if (count == 0) {
//            throw new BusinessException(ErrorCode.PARAMS_ERROR, "模型名称重复");
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "模型不存在");
        }

        QueryWrapper<Job> jobQueryWrapper = new QueryWrapper<>();
        jobQueryWrapper.eq("jobName",jobName);
        long count1 = jobMapper.selectCount(jobQueryWrapper);
        if (count1 > 0) {
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "业务名称已经重复，请重新输入");
        }

        return ResultUtils.success("success");
    }
}




