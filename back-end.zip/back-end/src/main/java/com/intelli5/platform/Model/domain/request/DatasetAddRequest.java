package com.intelli5.platform.Model.domain.request;

import lombok.Data;

import java.io.Serializable;

@Data
public class DatasetAddRequest implements Serializable {
    private static final long serialVersionUID = -1968407887146498964L;

    private String deviceIP;
    private String devicePort;
    private String datasetName;
    private String datasetAddress;
    private String supportJob;
    private Integer userId;
}
