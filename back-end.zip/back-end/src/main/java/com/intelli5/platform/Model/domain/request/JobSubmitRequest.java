package com.intelli5.platform.Model.domain.request;


import lombok.Data;

import java.io.Serializable;

@Data
public class JobSubmitRequest implements Serializable {

    private static final long serialVersionUID = 465453296235282844L;

    private Integer id;
    private String myJob;

}
