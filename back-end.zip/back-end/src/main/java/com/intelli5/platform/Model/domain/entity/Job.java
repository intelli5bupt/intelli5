package com.intelli5.platform.Model.domain.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import lombok.Data;

/**
 * 
 * @TableName job
 */
@TableName(value ="job")
@Data
public class Job implements Serializable {
    /**
     * 
     */
    @TableId(type = IdType.AUTO)
    private Integer id;

    /**
     * 
     */
    private String jobName;

    /**
     * 
     */
    private String jobDescription;

    /**
     * 
     */
    private String jobType;

    /**
     * 
     */
    private String jobTypeDescription;

    /**
     * 
     */
    private Integer datasetId;

    /**
     * 
     */
    private String jobDatasetDescription;

    /**
     * 
     */
    private Integer modelId;

    /**
     * 
     */
    private String budget;

    /**
     * 
     */
    private String modelDeployStrategy;

    /**
     * 
     */
    private String jobSafetyStrategy;

    /**
     * 
     */
    private Integer userId;

    /**
     * 
     */
    private String jobModelName;

    /**
     * 
     */
    private String jobSName;

    /**
     * 
     */
    private String jobUsername;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}