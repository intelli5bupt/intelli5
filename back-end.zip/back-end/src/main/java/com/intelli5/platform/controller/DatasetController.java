package com.intelli5.platform.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.intelli5.platform.Model.domain.entity.Dataset;
import com.intelli5.platform.Model.domain.entity.Device;
import com.intelli5.platform.Model.domain.entity.Job;
import com.intelli5.platform.Model.domain.entity.User;
import com.intelli5.platform.Model.domain.request.DatasetAddRequest;
import com.intelli5.platform.Model.domain.request.DatasetQueryRequest;
import com.intelli5.platform.Model.domain.request.DatasetUpdateRequest;
import com.intelli5.platform.Model.domain.request.JobQueryRequest;
import com.intelli5.platform.Model.domain.vo.DatasetVO;
import com.intelli5.platform.Model.domain.vo.JobVO;
import com.intelli5.platform.common.BaseResponse;
import com.intelli5.platform.common.DeleteRequest;
import com.intelli5.platform.common.ErrorCode;
import com.intelli5.platform.common.ResultUtils;
import com.intelli5.platform.service.DatasetService;
import com.intelli5.platform.service.DeviceService;
import com.intelli5.platform.service.JobService;
import com.intelli5.platform.service.UserService;
import com.intelli5.platform.utils.HttpCommunicate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/data")
@Slf4j
public class DatasetController {

    @Resource
    private UserService userService;

    @Resource
    private DatasetService datasetService;

    @Resource
    private JobService jobService;

    @Resource
    private DeviceService deviceService;


    @PostMapping("/data_register")
    public BaseResponse addDataset(@RequestBody DatasetAddRequest datasetAddRequest, HttpServletRequest request, HttpServletResponse resp){
        User userLogin = userService.getLoginUser(request);
        if (datasetAddRequest == null) {
//            throw new BusinessException(ErrorCode.PARAMS_ERROR);
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "参数错误");
        }

        Dataset dataset = new Dataset();
        BeanUtils.copyProperties(datasetAddRequest, dataset);
        dataset.setUserId(userLogin.getId());

        BaseResponse response = datasetService.validDataset(dataset, true, request);
        if (response.getCode() != 200 ){
            return response;
        }

        QueryWrapper<Job> queryWrapper1 = new QueryWrapper();
        queryWrapper1.eq("jobSName", dataset.getSupportJob());
        List<Job> list = jobService.list(queryWrapper1);
        List<Integer> idList = list.stream().map(Job::getId).collect(Collectors.toList());
        dataset.setJobId(idList.get(0));

        QueryWrapper<Device> queryWrapper2 = new QueryWrapper();
        queryWrapper2.eq("deviceIP", dataset.getDeviceIP());
        List<Device> deviceList = deviceService.list(queryWrapper2);
        List<Integer> deviceID = deviceList.stream().map(Device::getId).collect(Collectors.toList());
        dataset.setDeviceId(deviceID.get(0));

        boolean result = datasetService.save(dataset);
        if (!result){
//            throw new BusinessException(ErrorCode.OPERATION_ERROR);
            return ResultUtils.error(ErrorCode.OPERATION_ERROR, "数据插入失败");
        }

        Map map = new HashMap<>();
        map.put("dataaddress", dataset.getDatasetAddress());
        map.put("job_type", "Edd-steel-v1-in_built-Wnet");
        map.put("device_ip",dataset.getDeviceIP());
        String postResult = HttpCommunicate.sendPost("http://10.112.76.172:43999/data/upload", map);

        System.out.println(postResult);
        String processResult = postResult.replace("\"", "");
        System.out.println(processResult);
        String address = "http://10.112.76.172:8080/#/details?job_id="+processResult+"&role=local&party_id=0&from=Job%20overview&page=1";


        return ResultUtils.success(address);

    }

    @PostMapping("/dataDelete")
    public BaseResponse<Boolean> deleteDataset(@RequestBody DeleteRequest deleteRequest, HttpServletRequest request){
        User user = userService.getLoginUser(request);

        if (deleteRequest == null || deleteRequest.getId() <= 0) {
//            throw new BusinessException(ErrorCode.PARAMS_ERROR);
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "参数错误");
        }
        long id = deleteRequest.getId();
        //判断该数据是否存在
        Dataset datasetID = datasetService.getById(id);
        if (datasetID == null) {
//            throw new BusinessException(ErrorCode.NOT_FOUND_ERROR);
            return ResultUtils.error(ErrorCode.NOT_FOUND_ERROR, "该数据不存在");
        }
        //仅本人可以删除
        if (!datasetID.getUserId().equals(user.getId())) {
//            throw new BusinessException(ErrorCode.NO_AUTH_ERROR);
            return ResultUtils.error(ErrorCode.NO_AUTH_ERROR, "非本人，不可删除");
        }

        boolean b = datasetService.removeById(id);

        return ResultUtils.success(b);
    }

    @PostMapping("/dataUpdate")
    public BaseResponse<Boolean> updateDataset(@RequestBody DatasetUpdateRequest datasetUpdateRequest, HttpServletRequest request){
        User user = userService.getLoginUser(request);
        if (datasetUpdateRequest == null || datasetUpdateRequest.getId() <= 0) {
            log.info(String.valueOf(datasetUpdateRequest.getId()));
//            throw new BusinessException(ErrorCode.PARAMS_ERROR);
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "参数错误");
        }

        Dataset dataset = new Dataset();
        BeanUtils.copyProperties(datasetUpdateRequest, dataset);

        //参数校验
        BaseResponse response = datasetService.validDataset(dataset, true,request);
        if (response.getCode() != 200 ){
            return response;
        }

        Integer id = datasetUpdateRequest.getId();
        //判断该数据是否存在
        Dataset datasetID = datasetService.getById(id);
        if (datasetID == null) {
//            throw new BusinessException(ErrorCode.NOT_FOUND_ERROR);
            return ResultUtils.error(ErrorCode.NOT_FOUND_ERROR, "该数据不存在");
        }
        //仅本人可以更新
        if (!datasetID.getUserId().equals(user.getId())) {
//            throw new BusinessException(ErrorCode.NO_AUTH_ERROR);
            return ResultUtils.error(ErrorCode.NO_AUTH_ERROR, "非本人，不可删除");
        }
        boolean result = datasetService.updateById(dataset);

        return ResultUtils.success(result);

    }

    @GetMapping("/list")
    public BaseResponse<List<DatasetVO>> listDataset(DatasetQueryRequest datasetQueryRequest, HttpServletRequest request){
        User user = userService.getLoginUser(request);
        Dataset datasetQuery = new Dataset();
        if (datasetQueryRequest != null) {
            BeanUtils.copyProperties(datasetQueryRequest, datasetQuery);
        }

        QueryWrapper<Dataset> queryWrapper = new QueryWrapper<>();
//        queryWrapper.eq("userId", user.getId());
        queryWrapper.eq("userId", user.getId());

        List<Dataset> datasetList = datasetService.list(queryWrapper);
        List<DatasetVO> datasetVOList = datasetList.stream().map(dataset -> {
            DatasetVO datasetVO = new DatasetVO();
            BeanUtils.copyProperties(dataset, datasetVO);
            return datasetVO;
        }).collect(Collectors.toList());

        return ResultUtils.success(datasetVOList);

    }

    @GetMapping("/supportJob")
    public BaseResponse<List<JobVO>> supportJobList(JobQueryRequest jobQueryRequest, HttpServletRequest request){
        User user = userService.getLoginUser(request);
        Job jobQuery = new Job();
        if (jobQueryRequest != null) {
            BeanUtils.copyProperties(jobQueryRequest, jobQuery);
        }

        QueryWrapper<Job> queryWrapper = new QueryWrapper<>();
        List<Job> jobList = jobService.list(queryWrapper);
        List<JobVO> jobVOList = jobList.stream().map(job -> {
            JobVO jobVO = new JobVO();
            BeanUtils.copyProperties(job, jobVO);
            jobVO.setSupportJob(jobVO.getJobSName());
            return jobVO;
        }).collect(Collectors.toList());

        return ResultUtils.success(jobVOList);


    }
}
