package com.intelli5.platform.daili;

import com.alibaba.fastjson.JSON;
import com.google.gson.JsonObject;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.http.Consts;
import org.apache.http.HttpEntity;
import org.apache.http.ParseException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Map;

public class HttpTest {

    private static final CloseableHttpClient httpclient = HttpClients.createDefault();

    public static String sendPost(String url, Map<String,String> map) {
        JsonObject jsonObject = new JsonObject();
        for(Map.Entry entry:map.entrySet()){
            jsonObject.addProperty(entry.getKey().toString(),entry.getValue().toString());
        }
        StringEntity entity = new StringEntity(jsonObject.toString(), Consts.UTF_8);
        HttpPost httppost = new HttpPost(url);
        httppost.setEntity(entity);
        CloseableHttpResponse response = null;
        try {
            response = httpclient.execute(httppost);
        } catch (IOException e) {
            e.printStackTrace();
        }
        HttpEntity entity1 = response.getEntity();
        String result = null;
        try {
            result = EntityUtils.toString(entity1);
        } catch (ParseException | IOException e) {
            e.printStackTrace();
        }
        return result;
    }

    public static void main(String[] args) {

        Map map = new HashMap<>();
        map.put("dataaddress", "11111");
        map.put("job_type", "Edd-steel-v1-in_built-Wnet");
        map.put("device_ip","156.241.135.200");
        sendPost("http://10.112.76.172:43999/data/upload", map);
    }




//    public static void main(String[] args) {
//        HttpClient httpClient = new HttpClient();
//        PostMethod postMethod = new PostMethod("http://10.128.194.181:43999/data/upload");
//
//        postMethod.addRequestHeader("accept", "/");
//        postMethod.addRequestHeader("Content-Type", "application/json;charset=utf8");
//
//        Map map = new HashMap<>();
//        map.put("dataadress", "这是数据地址");
//        map.put("job_type", "这是任务类型");
//        map.put("device_ip","这是设备IP");
//
//        postMethod.addParameter("params", JSON.toJSONString(map));
//        String result = "";
//        try {
//            int code = httpClient.executeMethod(postMethod);
//            if(code == 200){
//                result = postMethod.getResponseBodyAsString();
//                System.out.println("result: " + result);
//            }
//        } catch (IOException e) {
//            throw new RuntimeException(e);
//        }
//    }
}
