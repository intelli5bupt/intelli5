package com.intelli5.platform.Model.domain.request;


import lombok.Data;

import java.io.Serializable;

@Data
public class DatasetUpdateRequest implements Serializable {
    private static final long serialVersionUID = 2153648355533627452L;

    private Integer id;
    private String deviceIP;
    private String devicePort;
    private String datasetName;
    private String datasetAddress;
    private String supportJob;
    private Integer userId;
}
