package com.intelli5.platform.Mapper;

import com.intelli5.platform.Model.domain.entity.Dataset;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author lenovo
* @description 针对表【dataset】的数据库操作Mapper
* @createDate 2022-11-24 16:02:51
* @Entity com.intelli5.platform.Model.domain.entity.Dataset
*/
public interface DatasetMapper extends BaseMapper<Dataset> {

}




