package com.intelli5.platform.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.intelli5.platform.Model.domain.entity.Job;
import com.intelli5.platform.common.BaseResponse;

/**
* @author lenovo
* @description 针对表【job】的数据库操作Service
* @createDate 2022-11-24 13:43:44
*/
public interface JobService extends IService<Job> {

    BaseResponse validJob(Job job, boolean add);

}
