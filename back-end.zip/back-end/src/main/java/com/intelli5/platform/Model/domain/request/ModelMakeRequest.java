package com.intelli5.platform.Model.domain.request;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

@Data
public class ModelMakeRequest implements Serializable {

    private static final long serialVersionUID = -7115568476371264442L;

    private Integer id;

    private String modelName;

//    private MultipartFile[] files;
    private HashMap files;
    private String encryptAlgorithm;

    private Long userId;


}
