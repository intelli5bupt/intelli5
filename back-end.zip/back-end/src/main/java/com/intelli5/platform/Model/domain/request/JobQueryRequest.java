package com.intelli5.platform.Model.domain.request;

import com.intelli5.platform.common.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

@Data
@EqualsAndHashCode(callSuper = true)
public class JobQueryRequest extends PageRequest implements Serializable {

    private static final long serialVersionUID = 138891814935822205L;
    private Integer id;

    private String jobName;

    private String jobDescription;

    private String jobType;

    private String jobTypeDescription;

    private String jobModelName;

    private String budget;

    private String modelDeployStrategy;

    private String jobSafetyStrategy;

    private String jobDatasetDescription;

    private String jobSName;

    private String jobUserName;

    private String supportJob;
}
