package com.intelli5.platform.service;

import com.intelli5.platform.Model.domain.entity.Model;
import com.baomidou.mybatisplus.extension.service.IService;
import com.intelli5.platform.common.BaseResponse;

/**
* @author lenovo
* @description 针对表【model】的数据库操作Service
* @createDate 2022-11-24 13:18:17
*/
public interface ModelService extends IService<Model> {

    /**
     * 检验是否符合规范
     *
     * @param model
     * @param add
     * @return
     */
    BaseResponse validModel(Model model, boolean add);

}
