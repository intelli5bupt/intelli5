package com.intelli5.platform.controller;


import com.intelli5.platform.Model.domain.entity.Model;
import com.intelli5.platform.Model.domain.entity.User;
import com.intelli5.platform.Model.domain.request.ModelMakeRequest;
import com.intelli5.platform.common.BaseResponse;
import com.intelli5.platform.common.ErrorCode;
import com.intelli5.platform.common.ResultUtils;
import com.intelli5.platform.service.ModelService;
import com.intelli5.platform.service.UserService;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/model")
public class ModelController {

    SimpleDateFormat sdf = new SimpleDateFormat("/yyyy/MM/dd/");

    @Resource
    private UserService userService;

    @Resource
    private ModelService modelService;

    @PostMapping("/model_maker")
    public BaseResponse<Long> modelMake(ModelMakeRequest modelMakeRequest, HttpServletRequest request){
        //首先判断是否登录
        User userLogin = userService.getLoginUser(request);
        if (modelMakeRequest == null){
//            throw new BusinessException(ErrorCode.PARAMS_ERROR);
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "参数错误");
        }

        Model model = new Model();
        BeanUtils.copyProperties(modelMakeRequest, model);
        //校验是否合规
        BaseResponse response = modelService.validModel(model, true);
        if (response.getCode() != 200 ){
            return response;
        }
        model.setUserId(userLogin.getId());
        boolean result = modelService.save(model);
        if (!result){
//            throw new BusinessException(ErrorCode.OPERATION_ERROR);
            return ResultUtils.error(ErrorCode.OPERATION_ERROR, "模型创建失败");
        }
        return ResultUtils.success(Long.valueOf(model.getId()));
    }

    @PostMapping("/modelUpload")
    public BaseResponse modelUpload(@RequestBody ModelMakeRequest modelMakeRequest, HttpServletRequest request){
        String name = (String) modelMakeRequest.getFiles().get("name");

        //首先判断是否登录
        User userLogin = userService.getLoginUser(request);
        if (modelMakeRequest == null){
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "参数错误");
        }

        Model model = new Model();
        BeanUtils.copyProperties(modelMakeRequest, model);
        //校验是否合规
        BaseResponse response = modelService.validModel(model, true);
        if (response.getCode() != 200 ){
            return response;
        }
        if (!name.endsWith(".pb")){
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "文件上传类型不正确");
        }

        model.setUserId(userLogin.getId());
        boolean result = modelService.save(model);
        if (!result){

            return ResultUtils.error(ErrorCode.OPERATION_ERROR, "模型创建失败");
        }


//        String format = sdf.format(new Date());
//        String realPath = request.getServletContext().getRealPath("/") + format;
//        File folder = new File(realPath);
//
//        if (!folder.exists()) {
//            folder.mkdirs();
//            System.out.println(realPath);
//        }

//        System.out.println("------------------------");
        return ResultUtils.success("success");

//        String newName = UUID.randomUUID().toString() + ".pb";
//
//        try {
//            files.get(0).transferTo(new File(folder, newName));
//            String url = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() +  "/api"  + format + newName;
////            String url = realPath + newName;
//            return ResultUtils.success(url);
//        } catch (IOException e) {
//            return ResultUtils.error(ErrorCode.OPERATION_ERROR, e.getMessage());
//        }


    }
}
