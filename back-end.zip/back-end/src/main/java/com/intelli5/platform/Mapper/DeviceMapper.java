package com.intelli5.platform.Mapper;

import com.intelli5.platform.Model.domain.entity.Device;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author lenovo
* @description 针对表【device】的数据库操作Mapper
* @createDate 2022-11-24 12:14:39
* @Entity com.intelli5.platform.Model.domain.entity.Device
*/
public interface DeviceMapper extends BaseMapper<Device> {

}




