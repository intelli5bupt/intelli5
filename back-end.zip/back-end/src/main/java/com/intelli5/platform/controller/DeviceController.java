package com.intelli5.platform.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.intelli5.platform.Model.domain.entity.Device;
import com.intelli5.platform.Model.domain.entity.User;
import com.intelli5.platform.Model.domain.request.DeviceAddRequest;
import com.intelli5.platform.Model.domain.request.DeviceQueryRequest;
import com.intelli5.platform.Model.domain.request.DeviceUpdateRequest;
import com.intelli5.platform.Model.domain.vo.DeviceVO;
import com.intelli5.platform.common.BaseResponse;
import com.intelli5.platform.common.DeleteRequest;
import com.intelli5.platform.common.ErrorCode;
import com.intelli5.platform.common.ResultUtils;
import com.intelli5.platform.service.DeviceService;
import com.intelli5.platform.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/device")
@Slf4j
public class DeviceController {

    @Resource
    private DeviceService deviceService;

    @Resource
    private UserService userService;

    /**
     * 设备创建 注册
     * @param deviceAddRequest
     * @param request
     * @return
     */
    @PostMapping("/deviceCreate")
    public BaseResponse<Long> addDevice(@RequestBody DeviceAddRequest deviceAddRequest, HttpServletRequest request){
        User userLogin = userService.getLoginUser(request);
        if (deviceAddRequest == null){
//            throw new BusinessException(ErrorCode.PARAMS_ERROR);
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "参数错误");
        }

        Device device = new Device();
        BeanUtils.copyProperties(deviceAddRequest, device);
        //校验
        BaseResponse response = deviceService.validDevice(device, true);
        if (response.getCode() != 200 ){
            return response;
        }

        device.setUserId(userLogin.getId());

        boolean result = deviceService.save(device);
        if (!result) {
//            throw new BusinessException(ErrorCode.OPERATION_ERROR);
            return ResultUtils.error(ErrorCode.OPERATION_ERROR, "设备数据插入错误");
        }
        return ResultUtils.success(Long.valueOf(device.getId()));

    }

    /**
     * 设备 删除
     * @param deleteRequest
     * @param request
     * @return
     */
    @PostMapping("/deviceDelete")
    public BaseResponse<Boolean> deleteDevice(@RequestBody DeleteRequest deleteRequest, HttpServletRequest request){
        User user = userService.getLoginUser(request);


        if (deleteRequest == null || deleteRequest.getId() <= 0) {
//            throw new BusinessException(ErrorCode.PARAMS_ERROR);
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "参数错误");
        }

        long id = deleteRequest.getId();
        //判断该设备是否存在
        Device deviceID = deviceService.getById(id);
        if (deviceID == null) {
//            throw new BusinessException(ErrorCode.NOT_FOUND_ERROR);
            return ResultUtils.error(ErrorCode.NOT_FOUND_ERROR, "该设备不存在");
        }
        //仅本人可以删除
        if (!deviceID.getUserId().equals(user.getId())) {
//            throw new BusinessException(ErrorCode.NO_AUTH_ERROR);
            return ResultUtils.error(ErrorCode.NOT_FOUND_ERROR, "无法删除，你不拥有此台设备");
        }

        boolean b = deviceService.removeById(id);

        return ResultUtils.success(b);
    }

    /**
     * 设备更新
     * @param deviceUpdateRequest
     * @param request
     * @return
     */
    @PostMapping("/deviceUpdate")
    public BaseResponse<Boolean> updateDevice(@RequestBody DeviceUpdateRequest deviceUpdateRequest, HttpServletRequest request){
        User user = userService.getLoginUser(request);
        if (deviceUpdateRequest == null || deviceUpdateRequest.getId() <= 0) {
//            throw new BusinessException(ErrorCode.PARAMS_ERROR);
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "参数错误");
        }
        Device device = new Device();
        BeanUtils.copyProperties(deviceUpdateRequest, device);
        //参数校验
        BaseResponse response = deviceService.validDevice(device, true);
        if (response.getCode() != 200 ){
            return response;
        }

        long id = deviceUpdateRequest.getId();
        //判断是否存在
        Device deviceID = deviceService.getById(id);
        if (deviceID == null) {
//            throw new BusinessException(ErrorCode.NOT_FOUND_ERROR);
            return ResultUtils.error(ErrorCode.NOT_FOUND_ERROR, "该设备不存在");
        }
        //仅本人可以更新
        if (!device.getUserId().equals(user.getId())){
//            throw new BusinessException(ErrorCode.NO_AUTH_ERROR);
            return ResultUtils.error(ErrorCode.NOT_FOUND_ERROR, "无法更新，你不拥有此台设备");
        }
        boolean result = deviceService.updateById(device);

        return ResultUtils.success(result);


    }

    /**
     * 设备展示界面
     * @param deviceQueryRequest
     * @param request
     * @return
     */
    @GetMapping("/list")
    public BaseResponse<List<DeviceVO>> listDevice(DeviceQueryRequest deviceQueryRequest, HttpServletRequest request){
        Device deviceQuery = new Device();
        if (deviceQueryRequest != null) {
            BeanUtils.copyProperties(deviceQueryRequest, deviceQuery);
        }

        User user = userService.getLoginUser(request);

        QueryWrapper<Device> queryWrapper = new QueryWrapper<>(deviceQuery);
        queryWrapper.eq("userId", user.getId());

        List<Device> deviceList = deviceService.list(queryWrapper);
        List<DeviceVO> deviceVOList = deviceList.stream().map(device -> {
            DeviceVO deviceVO = new DeviceVO();
            BeanUtils.copyProperties(device, deviceVO);
            return deviceVO;
        }).collect(Collectors.toList());

        return ResultUtils.success(deviceVOList);

    }

//    @GetMapping("/deviceRetrieve")
//    public void retrieveDevice() {
//
//    }
}
