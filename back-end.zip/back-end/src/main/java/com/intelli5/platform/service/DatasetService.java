package com.intelli5.platform.service;

import com.intelli5.platform.Model.domain.entity.Dataset;
import com.baomidou.mybatisplus.extension.service.IService;
import com.intelli5.platform.common.BaseResponse;

import javax.servlet.http.HttpServletRequest;

/**
* @author lenovo
* @description 针对表【dataset】的数据库操作Service
* @createDate 2022-11-24 16:02:51
*/
public interface DatasetService extends IService<Dataset> {

    BaseResponse validDataset(Dataset dataset, boolean add, HttpServletRequest request);

}
