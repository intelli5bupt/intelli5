package com.intelli5.platform.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.intelli5.platform.Mapper.JobMapper;
import com.intelli5.platform.Model.domain.entity.Dataset;
import com.intelli5.platform.Model.domain.entity.Job;
import com.intelli5.platform.Model.domain.entity.Model;
import com.intelli5.platform.Model.domain.entity.User;
import com.intelli5.platform.Model.domain.request.*;
import com.intelli5.platform.Model.domain.vo.JobVO;
import com.intelli5.platform.Model.domain.vo.ModelVO;
import com.intelli5.platform.Model.domain.vo.MyjobVO;
import com.intelli5.platform.common.BaseResponse;
import com.intelli5.platform.common.DeleteRequest;
import com.intelli5.platform.common.ErrorCode;
import com.intelli5.platform.common.ResultUtils;
import com.intelli5.platform.service.DatasetService;
import com.intelli5.platform.service.JobService;
import com.intelli5.platform.service.ModelService;
import com.intelli5.platform.service.UserService;
import com.intelli5.platform.utils.HttpCommunicate;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.intelli5.platform.constant.UserConstant.USER_LOGIN_STATE;

@RestController
@RequestMapping("/job")
public class JobController {

    @Resource
    private UserService userService;

    @Resource
    private ModelService modelService;

    @Resource
    private JobService jobService;

    @Resource
    private DatasetService datasetService;

    @Resource
    private JobMapper jobMapper;

    /**
     * 创建任务
     * @param jobAddRequest
     * @param request
     * @return
     */
    @PostMapping("/jobCreate")
    public BaseResponse<Integer> jobAdd(@RequestBody JobAddRequest jobAddRequest, HttpServletRequest request){
        User userLogin = userService.getLoginUser(request);

        if (jobAddRequest == null){
//            throw new BusinessException(ErrorCode.PARAMS_ERROR);
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "参数错误");
        }

        Job job = new Job();
        BeanUtils.copyProperties(jobAddRequest, job);

        BaseResponse response = jobService.validJob(job, true);
        if (response.getCode() != 200 ){
            return response;
        }

        //根据模型名称获取模型Id
        QueryWrapper<Model> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("modelName", job.getJobModelName());
        List<Model> list = modelService.list(queryWrapper);
        List<Integer> idList = list.stream().map(Model::getId).collect(Collectors.toList());

        job.setUserId(userLogin.getId());
        job.setJobUsername(userLogin.getUsername());
        job.setJobSName(job.getJobName() + "——"+ job.getJobModelName() + "——" + job.getJobUsername());
        job.setModelId(idList.get(0));

        boolean result = jobService.save(job);
        if (!result) {
//            throw new BusinessException(ErrorCode.OPERATION_ERROR, "任务创建失败");
            return ResultUtils.error(ErrorCode.OPERATION_ERROR, "任务创建失败");
        }

        return ResultUtils.success(job.getId());

    }

    /**
     * 删除任务
     * @param deleteRequest
     * @param request
     * @return
     */
    @PostMapping("/jobDelete")
    public BaseResponse<Boolean> jobDelete(@RequestBody DeleteRequest deleteRequest, HttpServletRequest request){
        User userLogin = userService.getLoginUser(request);

        if (deleteRequest == null || deleteRequest.getId() <= 0) {
//            throw new BusinessException(ErrorCode.PARAMS_ERROR);
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "有参数为空");
        }

        long id = deleteRequest.getId();
        //判断任务是否存在
        Job jobID = jobService.getById(id);
        if (jobID == null){
//            throw new BusinessException(ErrorCode.NOT_FOUND_ERROR, "任务不存在");
            return ResultUtils.error(ErrorCode.NOT_FOUND_ERROR, "任务不存在");
        }
        //仅本人可以删除
        if (!jobID.getUserId().equals(userLogin.getId())) {
//            throw new BusinessException(ErrorCode.NO_AUTH_ERROR, "无法删除，你不是该业务的创建者");
            return ResultUtils.error(ErrorCode.NO_AUTH_ERROR, "无法删除，你不是该业务的创建者");
        }

        boolean b = jobService.removeById(id);

        return ResultUtils.success(b);

    }

    /**
     * 任务更新
     * @param jobUpdateRequest
     * @param request
     * @return
     */
    @PostMapping("/jobUpdate")
    public BaseResponse<Boolean> jobUpdate(@RequestBody JobUpdateRequest jobUpdateRequest, HttpServletRequest request){
        User userLogin = userService.getLoginUser(request);
        if (jobUpdateRequest == null || jobUpdateRequest.getId() <= 0) {
//            throw new BusinessException(ErrorCode.PARAMS_ERROR);
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "有参数为空");
        }

        Job job = new Job();
        BeanUtils.copyProperties(jobUpdateRequest, job);

        BaseResponse response = jobService.validJob(job, true);
        if (response.getCode() != 200 ){
            return response;
        }

        long id = jobUpdateRequest.getId();
        //判断任务是否存在
        Job jobID = jobService.getById(id);
        if (jobID == null){
//            throw new BusinessException(ErrorCode.NOT_FOUND_ERROR, "任务不存在");
            return ResultUtils.error(ErrorCode.NOT_FOUND_ERROR, "任务不存在");
        }
        //仅本人可以更新
        if (!jobID.getUserId().equals(userLogin.getId())) {
//            throw new BusinessException(ErrorCode.NO_AUTH_ERROR, "无法修改，你不是该业务的创建者");
            return ResultUtils.error(ErrorCode.NO_AUTH_ERROR, "无法修改，你不是该业务的创建者");
        }
        boolean result = jobService.updateById(job);

        return ResultUtils.success(result);
    }


    @GetMapping("/list")
    public BaseResponse<List<JobVO>> listJob(JobQueryRequest jobQueryRequest, HttpServletRequest request){
        Job jobQuery = new Job();
        if (jobQueryRequest != null) {
            BeanUtils.copyProperties(jobQueryRequest, jobQuery);
        }

        QueryWrapper<Job> queryWrapper = new QueryWrapper<>(jobQuery);
        List<Job> jobList = jobService.list(queryWrapper);
        List<JobVO> jobVOList = jobList.stream().map(job -> {
            JobVO jobVO = new JobVO();
            BeanUtils.copyProperties(job, jobVO);
            return jobVO;
        }).collect(Collectors.toList());

        return ResultUtils.success(jobVOList);

    }

    @PostMapping("/detailList")
    public BaseResponse<List<JobVO>> jobDetailList(@RequestBody JobQueryRequest jobQueryRequest, HttpServletRequest request){
        Job jobQuery = new Job();
        if (jobQueryRequest != null) {
            BeanUtils.copyProperties(jobQueryRequest, jobQuery);
        }

        QueryWrapper<Job> queryWrapper = new QueryWrapper<>();

        queryWrapper.eq("id",jobQuery.getId());
        List<Job> jobList = jobService.list(queryWrapper);
        List<JobVO> jobVOList = jobList.stream().map(job -> {
            JobVO jobVO = new JobVO();
            BeanUtils.copyProperties(job, jobVO);
            return jobVO;
        }).collect(Collectors.toList());

        System.out.println(jobVOList.get(0).getJobDescription());
        return ResultUtils.success(jobVOList);
    }

//    @PostMapping("/jobSubmit")
//    public void jobSubmit(){
//
//        Map map = new HashMap<>();
//
//        HttpCommunicate.sendPost("url",)
//    }

    @GetMapping("/myJobList")
    public BaseResponse<List<MyjobVO>> myJobList(JobQueryRequest jobQueryRequest, HttpServletRequest request){
        User userLogin = userService.getLoginUser(request);

        Map<String, List<String>> jobDetailList = new HashMap<>();
        Job jobQyery = new Job();
        if (jobQueryRequest != null) {
            BeanUtils.copyProperties(jobQueryRequest, jobQyery);
        }
        QueryWrapper<Job> jobQueryWrapper = new QueryWrapper<>();
//        jobQueryWrapper.eq("userId", userLogin.getId());
        jobQueryWrapper.eq("userId", userLogin.getId());
        List<Job> jobList = jobService.list(jobQueryWrapper);
        List<Integer> jobIdList = jobList.stream().map(Job::getId).collect(Collectors.toList());
//        List<String> jobNameList = jobList.stream().map(Job::getJobSName).collect(Collectors.toList());

        List<JobVO> jobVOList = jobList.stream().map(job -> {
            JobVO jobVO = new JobVO();
            BeanUtils.copyProperties(job, jobVO);
            return jobVO;
        }).collect(Collectors.toList());

        for (JobVO jovIter : jobVOList) {
            System.out.println("业务ID：" + jovIter.getId());
            ArrayList<String> jobNameList = new ArrayList();

            QueryWrapper<Dataset> datasetQueryWrapper = new QueryWrapper<>();
            datasetQueryWrapper.eq("jobId", jovIter.getId());
            List<Dataset> datasetList = datasetService.list(datasetQueryWrapper);
            List<Integer> userIdList = datasetList.stream().map(Dataset::getUserId).collect(Collectors.toList());

            for (int j : userIdList) {

                System.out.println("我创建的业务ID: " + jovIter.getId() +"，参与的用户id" + j);


                QueryWrapper<User> userQueryWrapper = new QueryWrapper<>();
                userQueryWrapper.eq("id",j);
                List<User> userList = userService.list(userQueryWrapper);
                List<String> usernameList = userList.stream().map(User::getUsername).collect(Collectors.toList());

                for (String k: usernameList) {
                    System.out.println("我创建的业务ID: " + jovIter.getId() +"，参与的用户id" + j + "，参与的用户名字" + k);
                    if (!k.equals(userLogin.getUsername())){
                        jobNameList.add(k);
                    }
                }
                jobDetailList.put(jovIter.getJobSName(), jobNameList);
            }

        }

        List<MyjobVO> myJobVOList = new ArrayList<>();


        MyjobVO myjobVO = new MyjobVO();

        for(String m: jobDetailList.keySet())
        {
            String test = String.join(",",jobDetailList.get(m));
//            System.out.println(  );
            myjobVO.setMyJob(m);
            myjobVO.setMyJobJoinUserName(test);
            myJobVOList.add(myjobVO);
        }

        myjobVO.setJobDetailList(jobDetailList);
        return ResultUtils.success(myJobVOList);
    }

    @GetMapping("/myJoinJobList")
    public BaseResponse<List<MyjobVO>> myJoinJobList(JobQueryRequest jobQueryRequest, HttpServletRequest request){
        Job jobQyery = new Job();
        if (jobQueryRequest != null) {
            BeanUtils.copyProperties(jobQueryRequest, jobQyery);
        }

//        User userLogin = new User();
        User loginUser = userService.getLoginUser(request);
        System.out.println( loginUser.getId());

        QueryWrapper<Dataset> queryWrapper = new QueryWrapper();
        queryWrapper.eq("userId",  loginUser.getId());
        List<Dataset> datasetList = datasetService.list(queryWrapper);
        List<String> stringList = datasetList.stream().map(Dataset::getSupportJob).collect(Collectors.toList());

        List<MyjobVO> myjobVOList = new ArrayList<>();
        MyjobVO myjobVO = new MyjobVO();

        for (String s:
             stringList) {
            String test = String.join(",",s);
            myjobVO.setJobJobListName(test);
            myjobVOList.add(myjobVO);
            System.out.println(test);
        }


        myjobVO.setJoinJobList(stringList);


        return ResultUtils.success(myjobVOList);
    }

    @GetMapping("/existModelList")
    public BaseResponse existModelList(ModelQueryRequest modelQueryRequest, HttpServletRequest request){
        User user = userService.getLoginUser(request);
        Model modelQuery = new Model();
        if (modelQueryRequest != null) {
            BeanUtils.copyProperties(modelQueryRequest, modelQuery);
        }

        QueryWrapper<Model> queryWrapper = new QueryWrapper<>();
        List<Model> modelList = modelService.list(queryWrapper);
        List<ModelVO> modelVOList = modelList.stream().map(model -> {
            ModelVO modelVO = new ModelVO();
            BeanUtils.copyProperties(model, modelVO);
            return modelVO;
        }).collect(Collectors.toList());

        return ResultUtils.success(modelVOList);
    }

    @PostMapping("/jobSubmit")
    public BaseResponse checkFateboard(@RequestBody JobSubmitRequest jobSubmitRequest, HttpServletRequest request){
        //验证登录
        User userLogin = userService.getLoginUser(request);

        Job jobQuery = new Job();
        if (jobSubmitRequest != null) {
            BeanUtils.copyProperties(jobSubmitRequest, jobQuery);
        }

        QueryWrapper<Job> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("userId",userLogin.getId());
        queryWrapper.eq("jobSName", jobSubmitRequest.getMyJob());
        long count = jobMapper.selectCount(queryWrapper);
        if (count <= 0){
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "所选业务不存在");
        }

        List<Job> jobList = jobService.list(queryWrapper);
        List<JobVO> jobVOList = jobList.stream().map(job -> {
            JobVO jobVO = new JobVO();
            BeanUtils.copyProperties(job, jobVO);
            return jobVO;
        }).collect(Collectors.toList());

        System.out.println(jobVOList.get(0).getJobDescription());

        Map map = new HashMap<>();
        String postResult = HttpCommunicate.sendPost("http://10.112.76.172:43999/api/jobjob", map);
        System.out.println(postResult);
        String processResult = postResult.replace("\"", "");
        System.out.println(processResult);
        String address = "http://10.112.76.172:8080/#/details?job_id=" + processResult+ "&role=guest&party_id=10000&from=Job%20overview&page=1";

        System.out.println("------------------"+address);

        return ResultUtils.success(address);

    }

}
