package com.intelli5.platform.Model.domain.vo;

import lombok.Data;

@Data
public class ModelVO {
    private Integer id;
    private String modelName;
}
