package com.intelli5.platform.Mapper;

import com.intelli5.platform.Model.domain.entity.Job;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author lenovo
* @description 针对表【job】的数据库操作Mapper
* @createDate 2022-11-27 16:18:34
* @Entity com.intelli5.platform.Model.domain.entity.Job
*/
public interface JobMapper extends BaseMapper<Job> {

}




