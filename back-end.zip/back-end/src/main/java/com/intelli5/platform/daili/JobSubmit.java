package com.intelli5.platform.daili;

public class JobSubmit {
}
