package com.intelli5.platform.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.intelli5.platform.Model.domain.entity.Device;
import com.intelli5.platform.common.BaseResponse;

/**
* @author lenovo
* @description 针对表【device】的数据库操作Service
* @createDate 2022-11-23 21:00:25
*/
public interface DeviceService extends IService<Device> {

    /**
     * 校验 是否符合规范
     *
     * @param device
     * @param add    是否为创建校验
     * @return
     */
    BaseResponse validDevice(Device device, boolean add);

}
