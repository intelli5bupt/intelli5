package com.intelli5.platform.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.intelli5.platform.Mapper.DeviceMapper;
import com.intelli5.platform.Model.domain.entity.Device;
import com.intelli5.platform.common.BaseResponse;
import com.intelli5.platform.common.ErrorCode;
import com.intelli5.platform.common.ResultUtils;
import com.intelli5.platform.service.DeviceService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
* @author lenovo
* @description 针对表【device】的数据库操作Service实现
* @createDate 2022-11-23 21:00:25
*/
@Service
public class DeviceServiceImpl extends ServiceImpl<DeviceMapper, Device>
    implements DeviceService{

    /**
     * @param device
     * @param add    是否为创建校验
     * @return
     */
    @Override
    public BaseResponse validDevice(Device device, boolean add) {
        if (device == null) {
//            throw new BusinessException(ErrorCode.PARAMS_ERROR);
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "有参数为空");
        }

        String deviceIP = device.getDeviceIP();
        String deviceNumber = device.getDeviceNumber();
        String devicePort = device.getDevicePort();
        String deviceName = device.getDeviceName();
        String deviceStatus = device.getDeviceStatus();
        System.out.println("userID" + device.getUserId());

        //所有参数都为 非空
        if (add) {
            if (StringUtils.isAnyBlank(deviceIP, deviceNumber, devicePort, deviceName,deviceStatus )) {
//                throw new BusinessException(ErrorCode.PARAMS_ERROR);
                System.out.println(deviceIP);
                System.out.println(deviceNumber);
                System.out.println(devicePort);
                System.out.println(deviceName);
                System.out.println(deviceStatus);
                return ResultUtils.error(ErrorCode.PARAMS_ERROR, "有参数为空");
            }
        }
        //设备IP与设备编号对应
        // 506506 10.128.173.86
        // 509509 10.128.206.152
        if ( !((deviceIP.equals("10.128.173.86") && deviceNumber.equals("506506")) || (deviceIP.equals("10.128.206.152") && deviceNumber.equals("509509"))) ){
//            throw new BusinessException(ErrorCode.PARAMS_ERROR, "设备IP和设备编号不对应");
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "设备IP和设备编号不对应");
        }
        //设备端口号 须使用43999
        if (!devicePort.equals("43999")){
//            throw new BusinessException(ErrorCode.PARAMS_ERROR, "设备端口号错误，应使用43999端口号");
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "设备端口号错误，应使用43999端口号");
        }

        String validPattern = "^-?[0-9]+";
        Matcher matcher = Pattern.compile(validPattern).matcher(validPattern);
        if (matcher.find()) {
//            throw new BusinessException(ErrorCode.PARAMS_ERROR, "设备编号内包含特殊字符，应为数字");
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "设备编号内包含特殊字符，应为数字");
        }

        return ResultUtils.success("success");
    }
}




