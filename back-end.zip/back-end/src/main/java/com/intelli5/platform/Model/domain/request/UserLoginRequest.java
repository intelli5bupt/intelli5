package com.intelli5.platform.Model.domain.request;

import lombok.Data;

import java.io.Serializable;


@Data
public class UserLoginRequest implements Serializable {

    private static final long serialVersionUID = -8044249939635784731L;

    private String username;

    private String passwd;
}
