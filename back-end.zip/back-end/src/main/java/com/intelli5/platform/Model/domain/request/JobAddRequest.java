package com.intelli5.platform.Model.domain.request;

import lombok.Data;

import java.io.Serializable;

@Data
public class JobAddRequest implements Serializable {
    private static final long serialVersionUID = 46701698399437963L;

    private Integer id;

    private String jobName;

    private String jobDescription;

    private String jobType;

    private String jobTypeDescription;

    private String jobModelName;

    private String budget;

    private String modelDeployStrategy;

    private String jobSafetyStrategy;

    private String jobDatasetDescription;

    private Integer userId;

    private Integer datasetId;
}
