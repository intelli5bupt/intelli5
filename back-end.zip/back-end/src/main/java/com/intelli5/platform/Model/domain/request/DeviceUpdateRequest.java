package com.intelli5.platform.Model.domain.request;


import lombok.Data;

import java.io.Serializable;

@Data
public class DeviceUpdateRequest implements Serializable {
    private static final long serialVersionUID = 9205195241669666204L;

    private Integer userId;

    private Integer id;

    private String deviceIP;

    private String deviceName;

    private String devicePort;

    private String deviceStatus;

    private String deviceNumber;

}
