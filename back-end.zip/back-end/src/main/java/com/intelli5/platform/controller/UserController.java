package com.intelli5.platform.controller;


import com.intelli5.platform.Model.domain.entity.User;
import com.intelli5.platform.Model.domain.request.UserLoginRequest;
import com.intelli5.platform.Model.domain.request.UserRegisterRequest;
import com.intelli5.platform.common.BaseResponse;
import com.intelli5.platform.common.ErrorCode;
import com.intelli5.platform.common.ResultUtils;
import com.intelli5.platform.exception.BusinessException;
import com.intelli5.platform.service.UserService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;

import static com.intelli5.platform.constant.UserConstant.USER_LOGIN_STATE;

@RestController
@RequestMapping("/user")
public class UserController {

    @Resource
    private UserService userService;

    @PostMapping("/register")
    public BaseResponse<String> userRegister(@RequestBody UserRegisterRequest userRegisterRequest){
        if (userRegisterRequest == null){
            return null;
        }

        String username = userRegisterRequest.getUsername();
        String passwd = userRegisterRequest.getPassword();
        String checkPassword = userRegisterRequest.getCheckPassword();
        String phone = userRegisterRequest.getPhone();
        String email = userRegisterRequest.getEmail();
        String company = userRegisterRequest.getCompany();

        BaseResponse response = userService.userRegister(username, passwd, checkPassword, phone, email, company);
        if (response.getCode() != 200) {
            return response;
        }

        return ResultUtils.success(username);
    }

    @PostMapping("/login")
    public BaseResponse<String> userLogin(@RequestBody UserLoginRequest userLoginRequest, HttpServletRequest request){
        if (userLoginRequest == null){
            return null;
        }

        String username = userLoginRequest.getUsername();
        String passwd = userLoginRequest.getPasswd();

        BaseResponse response = userService.userLogin(username, passwd, request);
        if (response.getCode() != 200) {
            return response;
        }

        return ResultUtils.success(username);
    }

    @GetMapping("/current")
    public BaseResponse<String> getCurrentUser(HttpServletRequest request) {
        Object userObj = request.getSession().getAttribute(USER_LOGIN_STATE);
        User currentUser = (User) userObj;
        if (currentUser == null) {
            throw new BusinessException(ErrorCode.NOT_LOGIN_ERROR);
        }
        long userId = currentUser.getId();
        // TODO 校验用户是否合法
        User user = userService.getById(userId);
        User safetyUser = userService.getSafetyUser(user);
//        return ResultUtils.success(safetyUser);
        return ResultUtils.success(safetyUser.getUsername());
    }

    @RequestMapping("/send")
    public void redirect(HttpServletResponse response){
        try {
            response.sendRedirect("http://10.112.76.172:8080");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}