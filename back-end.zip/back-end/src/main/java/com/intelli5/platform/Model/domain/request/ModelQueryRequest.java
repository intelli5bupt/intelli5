package com.intelli5.platform.Model.domain.request;


import lombok.Data;

import java.io.Serializable;

@Data
public class ModelQueryRequest implements Serializable {

    private static final long serialVersionUID = -8561028771478749478L;
}
