package com.intelli5.platform.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.intelli5.platform.Mapper.DeviceMapper;
import com.intelli5.platform.Mapper.JobMapper;
import com.intelli5.platform.Model.domain.entity.Dataset;
import com.intelli5.platform.Model.domain.entity.Device;
import com.intelli5.platform.Model.domain.entity.Job;
import com.intelli5.platform.common.BaseResponse;
import com.intelli5.platform.common.ErrorCode;
import com.intelli5.platform.common.ResultUtils;
import com.intelli5.platform.service.DatasetService;
import com.intelli5.platform.Mapper.DatasetMapper;
import com.sun.org.apache.regexp.internal.RE;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
* @author lenovo
* @description 针对表【dataset】的数据库操作Service实现
* @createDate 2022-11-24 16:02:51
*/
@Service
@Slf4j
public class DatasetServiceImpl extends ServiceImpl<DatasetMapper, Dataset>
    implements DatasetService{


    @Resource
    private DeviceMapper deviceMapper;

    @Resource
    private JobMapper jobMapper;

    @Resource
    private DatasetMapper datasetMapper;

    @Override
    public BaseResponse validDataset(Dataset dataset, boolean add, HttpServletRequest request) {
        if (dataset == null) {
//            throw new BusinessException(ErrorCode.PARAMS_ERROR);
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "有参数为空");
        }

        String deviceIP = dataset.getDeviceIP();
        String devicePort = dataset.getDevicePort();
        String datasetName = dataset.getDatasetName();
        String datasetAddress = dataset.getDatasetAddress();
        String supportJob = dataset.getSupportJob();
        Integer userId = dataset.getUserId();

        //所有参数都为 非空
        if (add) {
            if (StringUtils.isAnyBlank(deviceIP, devicePort, datasetName, datasetAddress, supportJob)) {
//                throw new BusinessException(ErrorCode.PARAMS_ERROR, "有参数为空");
                return ResultUtils.error(ErrorCode.PARAMS_ERROR, "有参数为空");
            }
        }

        //判断当前用户 该 设备是否注册
        QueryWrapper<Device> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("userId", userId);
        queryWrapper.eq("deviceIP",deviceIP);
        long count = deviceMapper.selectCount(queryWrapper);
        if (count == 0) {
//            throw new BusinessException(ErrorCode.PARAMS_ERROR, "该设备未注册");

            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "该设备未注册");
//            return ResponseResult(ErrorCode.PARAMS_ERROR,"", "错误" );
        }

        //判断该业务 是否已被创建
        QueryWrapper<Job> jobQueryWrapper = new QueryWrapper<>();
        jobQueryWrapper.eq("jobSName",supportJob);
        long countJob = jobMapper.selectCount(jobQueryWrapper);
        if (countJob == 0){
//            throw new BusinessException(ErrorCode.PARAMS_ERROR, "该业务未被创建");
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "该业务未被创建");
        }

        //判断该用户是否已经加入该业务，如已经加入，想修改请修改信息
        QueryWrapper<Dataset> datasetQueryWrapper = new QueryWrapper<>();
        datasetQueryWrapper.eq("supportJob", supportJob);
        datasetQueryWrapper.eq("userId", request.getSession().getId());
        long countDataset = datasetMapper.selectCount(datasetQueryWrapper);
        if (countDataset > 0){
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "您已加入该业务，如需修改相关信息，请点击修改按钮");
        }


        if (!datasetAddress.equals("./dataUpload/")){
            return ResultUtils.error(ErrorCode.PARAMS_ERROR,"数据地址填写错误，应填写./dataUpload/");
        }
        //设备端口号 须使用43999
        if (!devicePort.equals("43999")){
//            throw new BusinessException(ErrorCode.PARAMS_ERROR, "设备端口号错误，应使用43999端口号");
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "设备端口号错误，应使用43999端口号");
        }

        return ResultUtils.success("success");
    }
}




