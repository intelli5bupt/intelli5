package com.intelli5.platform.Mapper;

import com.intelli5.platform.Model.domain.entity.Model;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author lenovo
* @description 针对表【model】的数据库操作Mapper
* @createDate 2022-11-24 13:18:17
* @Entity com.intelli5.platform.Model.domain.entity.Model
*/
public interface ModelMapper extends BaseMapper<Model> {

}




