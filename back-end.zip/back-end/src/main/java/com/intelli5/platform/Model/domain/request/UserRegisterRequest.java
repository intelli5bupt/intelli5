package com.intelli5.platform.Model.domain.request;

import lombok.Data;

import java.io.Serializable;

@Data
public class UserRegisterRequest implements Serializable {

    private static final long serialVersionUID = -5670986584930229573L;

    private String username;

    private String password;

    private String checkPassword;

    private String phone;

    private String email;

    private String company;
}
