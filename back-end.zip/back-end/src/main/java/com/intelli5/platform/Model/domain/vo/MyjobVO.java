package com.intelli5.platform.Model.domain.vo;

import lombok.Data;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

@Data
public class MyjobVO implements Serializable {
    private static final long serialVersionUID = 8740832759005812657L;

    private String id;

    private Map<String, List<String>> jobDetailList;

    private List<String> joinJobList;

    private String jobDetailListName;

    private String myJob;

    private String myJobJoinUserName;

    private String jobJobListName;


}
