package com.intelli5.platform.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.intelli5.platform.Mapper.UserMapper;
import com.intelli5.platform.Model.domain.entity.User;
import com.intelli5.platform.common.BaseResponse;
import com.intelli5.platform.common.ErrorCode;
import com.intelli5.platform.common.ResultUtils;
import com.intelli5.platform.exception.BusinessException;
import com.intelli5.platform.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
* @author lenovo
* @description 针对表【user】的数据库操作Service实现
* @createDate 2022-11-23 16:37:33
*/
@Service
@Slf4j
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService{

    @Resource
    private UserMapper userMapper;

    /**
     * 盐值
     */
    private static final String SALT = "Intelli5";

    /**
     *  用户登录状态键
     */
    private static final String USER_LOGIN_STATE = "userLoginState";

    @Override
    public BaseResponse userRegister(String username, String passwd, String checkPassword, String phone, String email, String company) {

        //1、 校验
        if (StringUtils.isAnyBlank(username, passwd, checkPassword, phone, email, company)){
            System.out.println("输入框内不得为空");
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "输入框内不得为空");
        }
        if (username.length() < 4) {
            System.out.println("用户名称不得少于4位");
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "用户名称不得少于4位");
        }
        if (passwd.length() < 8 || checkPassword.length() < 8) {
            System.out.println("密码或者验证密码需不少于8位");
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "密码或者验证密码需不少于8位");
        }


        //账户不包含特殊字符
        String validPattern = "[`~!@#$%^&*()+=|{}':;',\\\\[\\\\].<>/?~！@#￥%……&*（）——+|{}【】‘；：”“’。，、？]";
        Matcher matcher = Pattern.compile(validPattern).matcher(username);
        if (matcher.find()) {
            System.out.println("用户内包含特殊字符");
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "用户内包含特殊字符");
        }

        //密码和校验密码相同
        if (!passwd.equals(checkPassword)) {
            System.out.println("密码和校验密码输入不一致");
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "密码和校验密码输入不一致");
        }

        //校验 手机号码
        String validPhonePattern = "^1[2-9]\\d{9}$";
        Matcher matcherPhone = Pattern.compile(validPhonePattern).matcher(phone);
        if (!matcherPhone.find()){
            System.out.println("请输入正确的手机号格式");
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "请输入正确的手机号格式");
        }

        //校验邮箱
        String validEmailPattern = "^\\s*\\w+(?:\\.{0,1}[\\w-]+)*@[a-zA-Z0-9]+(?:[-.][a-zA-Z0-9]+)*\\.[a-zA-Z]+\\s*$";
        Matcher matcherEmail = Pattern.compile(validEmailPattern).matcher(email);
        if (!matcherEmail.find()){
            System.out.println("请输入正确的邮箱格式");
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "请输入正确的邮箱格式");
        }


        //账户不能重复
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("username", username);
        long count = this.count(queryWrapper);
        if (count > 0) {
            System.out.println("该用户名已存在，请重新输入新的用户名");
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "该用户名已存在，请重新输入新的用户名");
        }

        //2 密码加密

        String encryptPassword = DigestUtils.md5DigestAsHex((SALT + passwd).getBytes());

        //3 插入数据
        User user = new User();
        user.setUsername(username);
        user.setPasswd(encryptPassword);
        user.setPhone(phone);
        user.setEmail(email);
        user.setCompany(company);

        boolean saveResult = this.save(user);
        if (!saveResult) {
            return ResultUtils.error(ErrorCode.OPERATION_ERROR, "创建用户失败");
        }


        return ResultUtils.success("success");

    }

    @Override
    public BaseResponse userLogin(String username, String passwd, HttpServletRequest request) {
        //1、 校验
        if (StringUtils.isAnyBlank(username, passwd)){
            System.out.println("输入框内不得为空");
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "输入框内不得为空");
        }
        if (username.length() < 4) {
            System.out.println("用户名称不得少于4位");
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "用户名称不得少于4位");
        }
        if (passwd.length() < 8 ) {
            System.out.println("密码需不少于8位");
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "密码需不少于8位");
        }


        //账户不包含特殊字符
        String validPattern = "[`~!@#$%^&*()+=|{}':;',\\\\[\\\\].<>/?~！@#￥%……&*（）——+|{}【】‘；：”“’。，、？]";
        Matcher matcher = Pattern.compile(validPattern).matcher(username);
        if (matcher.find()) {
            System.out.println("用户内包含特殊字符");
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "用户内包含特殊字符");
        }


        //2 密码加密

        String encryptPassword = DigestUtils.md5DigestAsHex((SALT + passwd).getBytes());

        //查询用户是否存在
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("username", username);
        queryWrapper.eq("passwd", encryptPassword);
        User user = userMapper.selectOne(queryWrapper);
        if (user == null){
            log.info("用户登陆失败，用户名和密码不匹配");
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "用户登陆失败，用户名和密码不匹配");
        }

        //用户脱敏
        User safetyUser = new User();
        safetyUser.setId(user.getId());
        safetyUser.setUsername(user.getUsername());
        safetyUser.setPhone(user.getPhone());
        safetyUser.setEmail(user.getEmail());
        safetyUser.setCompany(user.getCompany());

        System.out.println(safetyUser.getUsername());

        //记录用户登陆状态
        request.getSession().setAttribute(USER_LOGIN_STATE, safetyUser);
        System.out.println(request.getSession().getAttribute(USER_LOGIN_STATE));
        System.out.println(request.getSession().getId());

        return ResultUtils.success("success");
    }


    /**
     * 获取当前登录用户
     *
     * @param request
     * @return
     */
    @Override
    public User getLoginUser(HttpServletRequest request) {
        // 先判断是否已登录
        Object userObj = request.getSession().getAttribute(USER_LOGIN_STATE);
        System.out.println(request.getSession().getAttribute(USER_LOGIN_STATE));
        System.out.println(request.getSession().getId());
        User currentUser = (User) userObj;
        if (currentUser == null || currentUser.getId() == null) {
            throw new BusinessException(ErrorCode.NOT_LOGIN_ERROR);
        }
        // 从数据库查询
        long userId = currentUser.getId();
        currentUser = this.getById(userId);
        if (currentUser == null) {
            throw new BusinessException(ErrorCode.NOT_LOGIN_ERROR);
        }
        return currentUser;
    }

    @Override
    public User getSafetyUser(User user) {
        if (user == null) {
            return null;
        }
        User safetyUser = new User();
        safetyUser.setId(user.getId());
        safetyUser.setUsername(user.getUsername());
        safetyUser.setPhone(user.getPhone());
        safetyUser.setEmail(user.getEmail());
        safetyUser.setCompany(user.getCompany());
        return safetyUser;
    }


}




