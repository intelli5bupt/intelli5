package com.intelli5.platform.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.intelli5.platform.Model.domain.entity.Model;
import com.intelli5.platform.common.BaseResponse;
import com.intelli5.platform.common.ErrorCode;
import com.intelli5.platform.common.ResultUtils;
import com.intelli5.platform.service.ModelService;
import com.intelli5.platform.Mapper.ModelMapper;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

/**
* @author lenovo
* @description 针对表【model】的数据库操作Service实现
* @createDate 2022-11-24 13:18:17
*/
@Service
public class ModelServiceImpl extends ServiceImpl<ModelMapper, Model>
    implements ModelService{

    /**
     * 检验方法 具体实现
     *
     * @param model
     * @param add
     * @return
     */
    @Override
    public BaseResponse validModel(Model model, boolean add) {
        if (model == null){
//            throw new BusinessException(ErrorCode.PARAMS_ERROR);
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "有参数为空");
        }

        String modelName = model.getModelName();

        String encryptAlgorithm = model.getEncryptAlgorithm();

        //所有参数都为 非空
        if (add) {
            if (StringUtils.isAnyBlank(modelName,  encryptAlgorithm )) {
//                throw new BusinessException(ErrorCode.PARAMS_ERROR, "参数为空");
                return ResultUtils.error(ErrorCode.PARAMS_ERROR, "参数为空");
            }
        }

        //模型名字不能重复
        QueryWrapper<Model> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("modelName", modelName);
        long count = this.count(queryWrapper);
        if (count > 0) {
//            throw new BusinessException(ErrorCode.PARAMS_ERROR, "模型名称已存在");
            return ResultUtils.error(ErrorCode.PARAMS_ERROR, "模型名称已存在");
        }

        return ResultUtils.success("success");
    }
}




