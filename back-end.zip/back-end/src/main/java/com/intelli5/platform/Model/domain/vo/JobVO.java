package com.intelli5.platform.Model.domain.vo;


import lombok.Data;

import java.io.Serializable;

@Data
public class JobVO implements Serializable {
    private static final long serialVersionUID = 7524166141453828227L;

    private Integer id;

    private String jobName;
    private String jobDescription;
    private String jobType;
    private String jobTypeDescription;
    private String jobModelName;
    private String budget;
    private String modelDeployStrategy;
    private String jobSafetyStrategy;
    private String jobDatasetDescription;
    private String jobSName;
    private Integer userId;
    private String jobUsername;

    private String supportJob;
}
