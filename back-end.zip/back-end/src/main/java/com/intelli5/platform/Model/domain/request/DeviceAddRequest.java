package com.intelli5.platform.Model.domain.request;


import lombok.Data;

import java.io.Serializable;


/**
 * 设备注册请求
 */
@Data
public class DeviceAddRequest implements Serializable {
    private static final long serialVersionUID = -6309199349615038288L;

    /**
     *  设备IP地址
     */
    private String deviceIP;

    /**
     * 设备编号
     */
    private String deviceNumber;

    /**
     * 设备端口号
     */
    private String devicePort;

    /**
     * 设备名称
     */
    private String deviceName;

    private String deviceStatus;


}
