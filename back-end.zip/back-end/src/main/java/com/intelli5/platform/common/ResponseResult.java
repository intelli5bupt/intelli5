package com.intelli5.platform.common;

import lombok.Data;

@Data
public class ResponseResult<T> {
    private int status;


    private T data;

    private String message;


    public ResponseResult(int status,  T data, String message) {
        this.status = status;

        this.data = data;
        this.message = message;
    }

    public ResponseResult(int status,  T data) {
        this(status,  data, "");
    }


}
