package com.intelli5.platform.daili;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class test {

    public static void main(String[] args) {
        Map<String, List<String>> jobDetailList = new HashMap<>();


    }


}
