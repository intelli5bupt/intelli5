package com.intelli5.platform.Model.domain.request;


import com.intelli5.platform.common.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

@Data
@EqualsAndHashCode(callSuper = true)
public class DeviceQueryRequest extends PageRequest implements Serializable {

    private static final long serialVersionUID = -6231753426750436750L;

    private Long id;

    private String deviceIP;

    private String deviceName;

    private String devicePort;

    private String deviceStatus;
}
