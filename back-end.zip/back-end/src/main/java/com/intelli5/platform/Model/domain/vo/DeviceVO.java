package com.intelli5.platform.Model.domain.vo;


import lombok.Data;

import java.io.Serializable;

/**
 * 设备视图
 */
@Data
public class DeviceVO implements Serializable {

    private static final long serialVersionUID = -716635942596127713L;

    private Integer id;

    private String deviceIP;

    private String deviceName;

    private String devicePort;

    private String deviceStatus;
    private Integer userId;
}
