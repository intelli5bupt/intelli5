//package com.intelli5.platform.service;
//
//import org.junit.jupiter.api.Assertions;
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//import javax.annotation.Resource;
//
//
//@SpringBootTest
//class UserServiceTest {
//
//    @Resource
//    private UserService userService;
//
//
//    @Test
//    public void testAddUser(){
//        User user = new User();
//        user.setId(6L);
//        user.setUsername("1");
//        user.setPasswd("123");
//        user.setPhone("111111111111");
//        user.setEmail("111@qq.com");
//        user.setCompany("WeBank");
//
//        boolean result = userService.save(user);
//
//        System.out.println(result);
//        Assertions.assertTrue(result);
//    }
//
//    @Test
//    void userRegister() {
//        String username = "lqc1";
//        String passwd = "123456lqc";
//        String checkPassword = "123456lqc";
//        String phone = "17732757918";
//        String email = "1787059444@qq.com";
//        String company = "BUPT";
//        long result = userService.userRegister(username, passwd, checkPassword, phone, email, company);
////        Assertions.assertEquals(-1, result);
//        System.out.println(result);
//    }
//
//    @Test
//    void userLogin(){
//
//    }
//
//}